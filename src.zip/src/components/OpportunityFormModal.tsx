import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import type { OpportunityStage } from '../types/opportunity'
import { useEffect } from 'react'

const stages: OpportunityStage[] = ['contacted', 'meeting', 'proposal', 'won', 'lost']

const schema = yup.object().shape({
  title: yup.string().required(),
  customerName: yup.string().required(),
  value: yup.number().required().positive(),
  stage: yup.string().oneOf(stages).required(),
})

export default function OpportunityFormModal({
  onClose,
  onSubmit,
  initialData,
}: {
  onClose: () => void
  onSubmit: (data: { title: string; customerName: string; value: number; stage: OpportunityStage }) => void
  initialData?: { title: string; customerName: string; value: number; stage: OpportunityStage }
}) {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<{ title: string; customerName: string; value: number; stage: OpportunityStage }>({
    resolver: yupResolver(schema),
    defaultValues: {
      title: '',
      customerName: '',
      value: 0,
      stage: 'contacted',
    },
  })

  useEffect(() => {
    if (initialData) {
      reset(initialData)
    } else {
      reset({
        title: '',
        customerName: '',
        value: 0,
        stage: 'contacted',
      })
    }
  }, [initialData, reset])

  return (
    <div className="fixed inset-0 bg-white/30 backdrop-blur-sm flex justify-center items-center z-50">
      <div className="bg-white p-6 rounded shadow-md w-full max-w-md">
        <h2 className="text-xl font-bold mb-4">
          {initialData ? 'Edit Opportunity' : 'Add New Opportunity'}
        </h2>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label className="block mb-1">Title</label>
            <input {...register('title')} className="w-full border px-3 py-2 rounded" />
            {errors.title && <p className="text-red-500 text-sm">{errors.title.message}</p>}
          </div>

          <div>
            <label className="block mb-1">Customer</label>
            <input {...register('customerName')} className="w-full border px-3 py-2 rounded" />
            {errors.customerName && <p className="text-red-500 text-sm">{errors.customerName.message}</p>}
          </div>

          <div>
            <label className="block mb-1">Value (USD)</label>
            <input type="number" {...register('value')} className="w-full border px-3 py-2 rounded" />
            {errors.value && <p className="text-red-500 text-sm">{errors.value.message}</p>}
          </div>

          <div>
            <label className="block mb-1">Stage</label>
            <select {...register('stage')} className="w-full border px-3 py-2 rounded">
              {stages.map((stage) => (
                <option key={stage} value={stage}>
                  {stage.charAt(0).toUpperCase() + stage.slice(1)}
                </option>
              ))}
            </select>
          </div>

          <div className="flex justify-end gap-2 mt-4">
            <button type="button" className="px-4 py-2 rounded bg-gray-300" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 rounded bg-blue-600 text-white">
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}