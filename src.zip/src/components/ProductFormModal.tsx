import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { useEffect } from 'react'
import type { Product } from '../types/product'

const schema = yup.object().shape({
    name: yup.string().required(),
    description: yup.string().required(),
    price: yup.number().positive().required(),
    stock: yup.number().integer().min(0).required(),
})

export default function ProductFormModal({
    onClose,
    onSubmit,
    initialData,
}: {
    onClose: () => void
    onSubmit: (data: Omit<Product, 'id'>) => void
    initialData?: Product
}) {
    const {
        register,
        handleSubmit,
        reset,
        formState: { errors },
    } = useForm({
        resolver: yupResolver(schema),
        defaultValues: {
            name: '',
            description: '',
            price: 0,
            stock: 0,
        },
    })

    useEffect(() => {
        if (initialData) {
            reset(initialData)
        }
    }, [initialData, reset])

    return (
        <div className="fixed inset-0 bg-white/30 backdrop-blur-sm flex justify-center items-center z-50">
            <div className="bg-white p-6 rounded shadow-md w-full max-w-md">
                <h2 className="text-xl font-bold mb-4">
                    {initialData ? 'Edit Product' : 'Add New Product'}
                </h2>

                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                    <div>
                        <label className="block mb-1">Name</label>
                        <input {...register('name')} className="w-full border px-3 py-2 rounded" />
                        {errors.name && <p className="text-red-500 text-sm">{errors.name.message}</p>}
                    </div>

                    <div>
                        <label className="block mb-1">Description</label>
                        <textarea {...register('description')} className="w-full border px-3 py-2 rounded" />
                        {errors.description && (
                            <p className="text-red-500 text-sm">{errors.description.message}</p>
                        )}
                    </div>

                    <div>
                        <label className="block mb-1">Price</label>
                        <input type="number" step="0.01" {...register('price')} className="w-full border px-3 py-2 rounded" />
                        {errors.price && <p className="text-red-500 text-sm">{errors.price.message}</p>}
                    </div>

                    <div>
                        <label className="block mb-1">Stock</label>
                        <input type="number" {...register('stock')} className="w-full border px-3 py-2 rounded" />
                        {errors.stock && <p className="text-red-500 text-sm">{errors.stock.message}</p>}
                    </div>

                    <div className="flex justify-end gap-2 mt-4">
                        <button type="button" className="px-4 py-2 rounded bg-gray-300" onClick={onClose}>
                            Cancel
                        </button>
                        <button type="submit" className="px-4 py-2 rounded bg-blue-600 text-white">
                            Save
                        </button>
                    </div>
                </form>
            </div>
        </div>
    )
}