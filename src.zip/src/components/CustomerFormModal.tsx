import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'

const schema = yup.object().shape({
    name: yup.string().required('Name is required'),
    email: yup.string().email('Invalid email').required('Email is required'),
    phone: yup.string().required('Phone is required'),
    tags: yup.string(), // comma-separated tags
})

interface CustomerFormModalProps {
    onClose: () => void
    onSubmit: (data: any) => void
    initialData?: {
        name: string
        email: string
        phone: string
        tags: string[]
    }
    isEdit?: boolean
}

export default function CustomerFormModal({ onClose, onSubmit, initialData, isEdit = false }: CustomerFormModalProps) {
    const {
        register,
        handleSubmit,
        reset,
        formState: { errors },
    } = useForm({
        resolver: yupResolver(schema),
        defaultValues: {
            name: initialData?.name || '',
            email: initialData?.email || '',
            phone: initialData?.phone || '',
            tags: initialData?.tags?.join(', ') || '',
        },
    })

    const submitHandler = (data: any) => {
        // parse tags into array
        const customerData = {
            ...data,
            tags: data.tags ? data.tags.split(',').map((t: any) => t.trim()) : [],
        }
        onSubmit(customerData)
        onClose()
    }

    useEffect(() => {
        reset({
            name: initialData?.name || '',
            email: initialData?.email || '',
            phone: initialData?.phone || '',
            tags: initialData?.tags?.join(', ') || '',
        })
    }, [initialData, reset])

    return (
        <div className="fixed inset-0 bg-white/30 backdrop-blur-sm flex justify-center items-center z-50">
            <div className="bg-white p-6 rounded shadow-md w-full max-w-md">
                <h2 className="text-xl font-bold mb-4">
                    {isEdit ? 'Edit Customer' : 'Add New Customer'}
                </h2>

                <form onSubmit={handleSubmit(submitHandler)} className="space-y-4">
                    <div>
                        <label className="block mb-1">Name</label>
                        <input {...register('name')} className="w-full border px-3 py-2 rounded" />
                        {errors.name && <p className="text-red-500 text-sm">{errors.name.message}</p>}
                    </div>

                    <div>
                        <label className="block mb-1">Email</label>
                        <input {...register('email')} className="w-full border px-3 py-2 rounded" />
                        {errors.email && <p className="text-red-500 text-sm">{errors.email.message}</p>}
                    </div>

                    <div>
                        <label className="block mb-1">Phone</label>
                        <input {...register('phone')} className="w-full border px-3 py-2 rounded" />
                        {errors.phone && <p className="text-red-500 text-sm">{errors.phone.message}</p>}
                    </div>

                    <div>
                        <label className="block mb-1">Tags (comma separated)</label>
                        <input {...register('tags')} className="w-full border px-3 py-2 rounded" />
                    </div>

                    <div className="flex justify-end gap-2 mt-4">
                        <button
                            type="button"
                            className="px-4 py-2 rounded bg-gray-300"
                            onClick={onClose}
                        >
                            Cancel
                        </button>
                        <button type="submit" className="px-4 py-2 rounded bg-blue-600 text-white">
                            Save
                        </button>
                    </div>
                </form>
            </div>
        </div>
    )
}