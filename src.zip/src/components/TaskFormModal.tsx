import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'

const schema = yup.object().shape({
    title: yup.string().required(),
    description: yup.string(),
    dueDate: yup.string().required('Due date is required'),
    status: yup.string().oneOf(['pending', 'done']).required(),
})

export default function TaskFormModal({ onClose, onSubmit, initialData }: any) {
    const {
        register,
        handleSubmit,
        reset,
        formState: { errors },
    } = useForm({
        resolver: yupResolver(schema),
        defaultValues: {
            title: '',
            description: '',
            dueDate: new Date().toISOString().split('T')[0],
            status: 'pending',
        },
    })

    useEffect(() => {
        if (initialData) {
            reset({
                title: initialData.title,
                description: initialData.description,
                dueDate: initialData.dueDate,
                status: initialData.status,
            })
        } else {
            reset({
                title: '',
                description: '',
                dueDate: new Date().toISOString().split('T')[0],
                status: 'pending',
            })
        }
    }, [initialData, reset])

    const submit = (data: any) => {
        onSubmit(data)
        reset()
    }

    return (
        <div className="fixed inset-0 bg-white/30 backdrop-blur-sm flex justify-center items-center z-50">
            <div className="bg-white p-6 rounded shadow-md w-full max-w-md">
                <h2 className="text-xl font-bold mb-4">
                    {initialData ? 'Edit Task' : 'Add New Task'}
                </h2>

                <form onSubmit={handleSubmit(submit)} className="space-y-4">
                    <div>
                        <label className="block mb-1">Title</label>
                        <input {...register('title')} className="w-full border px-3 py-2 rounded" />
                        {errors.title && <p className="text-red-500 text-sm">{errors.title.message}</p>}
                    </div>

                    <div>
                        <label className="block mb-1">Description</label>
                        <textarea {...register('description')} className="w-full border px-3 py-2 rounded" />
                    </div>

                    <div>
                        <label className="block mb-1">Due Date</label>
                        <input type="date" {...register('dueDate')} className="w-full border px-3 py-2 rounded" />
                        {errors.dueDate && <p className="text-red-500 text-sm">{errors.dueDate.message}</p>}
                    </div>

                    <div>
                        <label className="block mb-1">Status</label>
                        <select {...register('status')} className="w-full border px-3 py-2 rounded">
                            <option value="pending">Pending</option>
                            <option value="done">Done</option>
                        </select>
                    </div>

                    <div className="flex justify-end gap-2 mt-4">
                        <button type="button" className="px-4 py-2 rounded bg-gray-300" onClick={onClose}>
                            Cancel
                        </button>
                        <button type="submit" className="px-4 py-2 rounded bg-green-600 text-white">
                            Save Task
                        </button>
                    </div>
                </form>
            </div>
        </div>
    )
}