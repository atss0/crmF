import { useForm, useFieldArray } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { useEffect } from 'react'
import type { Invoice } from '../types/invoice'

const schema = yup.object().shape({
  customerName: yup.string().required(),
  date: yup.string().required(),
  status: yup.string().oneOf(['paid', 'pending', 'overdue']).required(),
  items: yup.array().of(
    yup.object().shape({
      productName: yup.string().required(),
      quantity: yup.number().positive().integer().required(),
      price: yup.number().positive().required(),
    })
  ).required().min(1, 'At least one item is required.'),
})

export default function InvoiceFormModal({
  onClose,
  onSubmit,
  initialData,
}: {
  onClose: () => void
  onSubmit: (data: Omit<Invoice, 'id'>) => void
  initialData?: Invoice
}) {
  const {
    register,
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<Omit<Invoice, 'id'>>({
    resolver: yupResolver(schema),
    defaultValues: {
      customerName: '',
      date: new Date().toISOString().split('T')[0],
      status: 'pending',
      items: [{ productName: '', quantity: 1, price: 0 }],
    },
  })

  const { fields, append, remove } = useFieldArray({
    control,
    name: 'items',
  })

  useEffect(() => {
    if (initialData) {
      reset(initialData)
    }
  }, [initialData, reset])

  return (
    <div className="fixed inset-0 bg-white/30 backdrop-blur-sm flex justify-center items-center z-50">
      <div className="bg-white p-6 rounded shadow-md w-full max-w-2xl">
        <h2 className="text-xl font-bold mb-4">
          {initialData ? 'Edit Invoice' : 'New Invoice'}
        </h2>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block mb-1">Customer Name</label>
              <input {...register('customerName')} className="w-full border px-3 py-2 rounded" />
              {errors.customerName && <p className="text-red-500 text-sm">{errors.customerName.message}</p>}
            </div>

            <div>
              <label className="block mb-1">Date</label>
              <input type="date" {...register('date')} className="w-full border px-3 py-2 rounded" />
              {errors.date && <p className="text-red-500 text-sm">{errors.date.message}</p>}
            </div>

            <div>
              <label className="block mb-1">Status</label>
              <select {...register('status')} className="w-full border px-3 py-2 rounded">
                <option value="pending">Pending</option>
                <option value="paid">Paid</option>
                <option value="overdue">Overdue</option>
              </select>
            </div>
          </div>

          <div>
            <h3 className="font-semibold mt-4 mb-2">Items</h3>
            {fields.map((item, index) => (
              <div key={item.id} className="grid grid-cols-4 gap-4 mb-2">
                <input
                  {...register(`items.${index}.productName`)}
                  placeholder="Product"
                  className="border px-2 py-1 rounded"
                />
                <input
                  type="number"
                  {...register(`items.${index}.quantity`)}
                  placeholder="Qty"
                  className="border px-2 py-1 rounded"
                />
                <input
                  type="number"
                  step="0.01"
                  {...register(`items.${index}.price`)}
                  placeholder="Price"
                  className="border px-2 py-1 rounded"
                />
                <button
                  type="button"
                  onClick={() => remove(index)}
                  className="text-red-600 text-sm underline"
                >
                  Remove
                </button>
              </div>
            ))}
            <button
              type="button"
              onClick={() => append({ productName: '', quantity: 1, price: 0 })}
              className="text-blue-600 text-sm underline mt-2"
            >
              + Add Item
            </button>
            {errors.items && <p className="text-red-500 text-sm mt-1">{(errors.items as any).message}</p>}
          </div>

          <div className="flex justify-end gap-2 mt-4">
            <button type="button" className="px-4 py-2 rounded bg-gray-300" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 rounded bg-purple-600 text-white">
              Save Invoice
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}