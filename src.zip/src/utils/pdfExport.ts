import { toPng } from 'html-to-image'
import jsPDF from 'jspdf'

export const downloadInvoicePDF = async (elementId: string, fileName = 'invoice.pdf') => {
  const element = document.getElementById(elementId)
  if (!element) {
    alert('PDF içeriği bulunamadı.')
    return
  }

  try {
    const dataUrl = await toPng(element, {
      cacheBust: true,
      pixelRatio: 2,
    })

    const pdf = new jsPDF('p', 'mm', 'a4')
    const img = new Image()
    img.src = dataUrl

    img.onload = () => {
      const pdfWidth = pdf.internal.pageSize.getWidth()
      const pdfHeight = (img.height * pdfWidth) / img.width

      pdf.addImage(dataUrl, 'PNG', 0, 0, pdfWidth, pdfHeight)
      pdf.save(fileName)
    }
  } catch (error) {
    console.error('PDF oluşturulurken hata oluştu:', error)
    alert('PDF oluşturulurken hata oluştu.')
  }
}