export type PaymentStatus = 'paid' | 'pending' | 'overdue'

export interface InvoiceItem {
  productName: string
  quantity: number
  price: number
}

export interface Invoice {
  id: number
  customerName: string
  items: InvoiceItem[]
  date: string
  status: PaymentStatus
}