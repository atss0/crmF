export const mockCustomers = [
    {
      id: 1,
      name: 'John Doe',
      email: 'john@example.com',
      phone: '+1-202-555-0123',
      tags: ['VIP', 'Active'],
    },
    {
      id: 2,
      name: 'Jane Smith',
      email: 'jane@company.com',
      phone: '+1-202-555-0199',
      tags: ['Inactive'],
    },
  ]
  
  export function getCustomers() {
    return Promise.resolve(mockCustomers)
  }