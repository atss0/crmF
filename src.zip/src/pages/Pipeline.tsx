import { useState } from 'react'
import type { Opportunity, OpportunityStage } from '../types/opportunity'
import OpportunityFormModal from '../components/OpportunityFormModal'

const stages: OpportunityStage[] = ['contacted', 'meeting', 'proposal', 'won', 'lost']
const stageLabels: Record<OpportunityStage, string> = {
    contacted: 'Contacted',
    meeting: 'Meeting',
    proposal: 'Proposal Sent',
    won: 'Won',
    lost: 'Lost',
}

export default function Pipeline() {
    const [opportunities, setOpportunities] = useState<Opportunity[]>([
        {
            id: 1,
            title: 'Website Redesign',
            customerName: 'John Doe',
            value: 3000,
            stage: 'contacted',
        },
        {
            id: 2,
            title: 'Social Media Campaign',
            customerName: 'Acme Inc.',
            value: 1500,
            stage: 'meeting',
        },
    ])
    const [showModal, setShowModal] = useState(false)
    const [editingOpportunity, setEditingOpportunity] = useState<Opportunity | undefined>(undefined)

    const getByStage = (stage: OpportunityStage) =>
        opportunities.filter((o) => o.stage === stage)

    const handleFormSubmit = (data: Omit<Opportunity, 'id'>) => {
        if (editingOpportunity) {
            // update
            setOpportunities((prev) =>
                prev.map((opp) =>
                    opp.id === editingOpportunity.id ? { ...opp, ...data, id: opp.id } : opp
                )
            )
            setEditingOpportunity(undefined)
        } else {
            // add
            const newOpp: Opportunity = { ...data, id: Date.now() }
            setOpportunities((prev) => [...prev, newOpp])
        }

        setShowModal(false)
    }

    const deleteOpportunity = (id: number) => {
        const confirmed = confirm('Are you sure you want to delete this opportunity?')
        if (confirmed) {
            setOpportunities((prev) => prev.filter((opp) => opp.id !== id))
        }
    }

    return (
        <div className="p-6">
            <div className="flex justify-between items-center mb-4">
                <h1 className="text-2xl font-bold">Sales Pipeline</h1>
                <button
                    onClick={() => setShowModal(true)}
                    className="bg-blue-600 text-white px-4 py-2 rounded"
                >
                    + New Opportunity
                </button>
            </div>
            <div className="grid grid-cols-5 gap-4">
                {stages.map((stage) => (
                    <div key={stage} className="bg-gray-100 p-3 rounded shadow-sm min-h-[300px]">
                        <h2 className="text-lg font-semibold mb-2">{stageLabels[stage]}</h2>
                        <div className="space-y-2">
                            {getByStage(stage).map((opp) => (
                                <div key={opp.id} className="p-3 bg-white rounded shadow text-sm relative">
                                    <div className="font-medium">{opp.title}</div>
                                    <div className="text-gray-500">{opp.customerName}</div>
                                    <div className="text-green-600 font-semibold">${opp.value}</div>

                                    <div className="absolute top-2 right-2 flex gap-2 text-xs">
                                        <button
                                            onClick={() => {
                                                setEditingOpportunity(opp)
                                                setShowModal(true)
                                            }}
                                            className="text-blue-600 hover:underline"
                                        >
                                            Edit
                                        </button>
                                        <button
                                            onClick={() => deleteOpportunity(opp.id)}
                                            className="text-red-600 hover:underline"
                                        >
                                            Delete
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                ))}
            </div>
            {showModal && (
                <OpportunityFormModal
                    onClose={() => {
                        setShowModal(false)
                        setEditingOpportunity(undefined)
                    }}
                    onSubmit={handleFormSubmit}
                    initialData={editingOpportunity}
                />
            )}
        </div>
    )
}