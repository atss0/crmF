// src/pages/LoginPage.tsx
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'

export default function LoginPage() {
    const navigate = useNavigate()
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [error, setError] = useState('')
    const { login } = useAuth()

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault()

        if (email === 'admin@example.com' && password === '123456') {
            login(email) // ⬅️ context'e kullanıcıyı yaz
            navigate('/')
        } else {
            setError('Invalid email or password.')
        }
    }

    return (
        <div className="flex justify-center items-center min-h-screen bg-gray-100">
            <form
                onSubmit={handleLogin}
                className="bg-white p-8 rounded shadow-md w-full max-w-md space-y-4"
            >
                <h1 className="text-2xl font-bold text-center">Login</h1>

                {error && <div className="text-red-600 text-sm">{error}</div>}

                <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Email"
                    required
                    className="w-full border px-4 py-2 rounded"
                />

                <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Password"
                    required
                    className="w-full border px-4 py-2 rounded"
                />

                <button
                    type="submit"
                    className="w-full bg-purple-600 text-white py-2 rounded hover:bg-purple-700"
                >
                    Login
                </button>
            </form>
        </div>
    )
}