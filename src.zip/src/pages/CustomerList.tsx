import { useEffect, useState } from 'react'
import { getCustomers } from '../services/customerService'
import CustomerFormModal from '../components/CustomerFormModal'

export interface Customer {
  id: number
  name: string
  email: string
  phone: string
  tags: string[]
}

export default function CustomerList() {
  const [customers, setCustomers] = useState<any>([])
  const [showModal, setShowModal] = useState(false)
  const [editingCustomer, setEditingCustomer] = useState<any>(null)
  const [searchTerm, setSearchTerm] = useState('')

  const filteredCustomers = customers.filter((c: any) => {
    const term = searchTerm.toLowerCase()
    return (
      c.name.toLowerCase().includes(term) ||
      c.email.toLowerCase().includes(term) ||
      c.tags.some((tag: string) => tag.toLowerCase().includes(term))
    )
  })

  useEffect(() => {
    getCustomers().then(setCustomers)
  }, [])

  const handleFormSubmit = (data: any) => {
    if (editingCustomer) {
      setCustomers((prev: any) =>
        prev.map((cust: any) =>
          cust.id === editingCustomer.id ? { ...cust, ...data } : cust
        )
      )
      setEditingCustomer(null)
    } else {
      const withId = { ...data, id: Date.now() }
      setCustomers((prev: any) => [...prev, withId])
    }
    setShowModal(false)
  }

  const deleteCustomer = (id: number) => {
    const confirmed = confirm('Are you sure you want to delete this customer?')
    if (confirmed) {
      setCustomers((prev: any) => prev.filter((c: any) => c.id !== id))
    }
  }

  const closeModal = () => {
    setShowModal(false)
    setEditingCustomer(null)
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold">Customer List</h1>
        <input
          type="text"
          placeholder="Search by name, email or tag..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="border px-3 py-2 rounded w-full max-w-sm mb-4"
        />
        <button
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
          onClick={() => setShowModal(true)}
        >
          + Add Customer
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full bg-white shadow-md rounded">
          <thead>
            <tr className="bg-gray-200 text-left">
              <th className="px-4 py-2">Name</th>
              <th className="px-4 py-2">Email</th>
              <th className="px-4 py-2">Phone</th>
              <th className="px-4 py-2">Tags</th>
              <th className="px-4 py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredCustomers.map((c: any) => (
              <tr key={c.id} className="border-t hover:bg-gray-50">
                <td className="px-4 py-2">{c.name}</td>
                <td className="px-4 py-2">{c.email}</td>
                <td className="px-4 py-2">{c.phone}</td>
                <td className="px-4 py-2">
                  {c.tags.map((tag: any) => (
                    <span key={tag} className="inline-block text-xs bg-gray-200 rounded px-2 py-1 mr-1">
                      {tag}
                    </span>
                  ))}
                </td>
                <td className="px-4 py-2">
                  <button
                    className="text-blue-600 hover:underline mr-2"
                    onClick={() => {
                      setEditingCustomer(c)
                      setShowModal(true)
                    }}
                  >
                    Edit
                  </button>
                  <button
                    className="text-red-600 hover:underline"
                    onClick={() => deleteCustomer(c.id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <CustomerFormModal
          onClose={closeModal}
          onSubmit={handleFormSubmit}
          initialData={editingCustomer}
          isEdit={!!editingCustomer}
        />
      )}
    </div>
  )
}