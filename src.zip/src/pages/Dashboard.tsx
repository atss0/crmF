// pages/Dashboard.tsx
import { useEffect, useState } from 'react'
import type { Invoice } from '../types/invoice'
import type { Customer } from '../types/customer'
import type { Product } from '../types/product'
import { useNavigate } from 'react-router-dom'

export default function Dashboard() {
    const [totalCustomers, setTotalCustomers] = useState<number>(0)
    const [totalProducts, setTotalProducts] = useState<number>(0)
    const [totalInvoices, setTotalInvoices] = useState<number>(0)
    const [totalRevenue, setTotalRevenue] = useState<number>(0)

    useEffect(() => {
        const customers = JSON.parse(localStorage.getItem('customers') || '[]') as Customer[]
        const products = JSON.parse(localStorage.getItem('products') || '[]') as Product[]
        const invoices = JSON.parse(localStorage.getItem('invoices') || '[]') as Invoice[]

        setTotalCustomers(customers.length)
        setTotalProducts(products.length)
        setTotalInvoices(invoices.length)
        setTotalRevenue(
            invoices.reduce(
                (acc, inv) =>
                    acc + inv.items.reduce((sum, item) => sum + item.price * item.quantity, 0),
                0
            )
        )
    }, [])

    return (
        <div className="p-6">
            <h1 className="text-2xl font-bold mb-6">Dashboard</h1>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card title="Customers" value={totalCustomers} to="/customers" />
                <Card title="Products" value={totalProducts} to="/products" />
                <Card title="Invoices" value={totalInvoices} to="/invoices" />
                <Card title="Tasks" value="Go to Tasks" to="/tasks" />
                <Card title="Pipeline" value="Go to Pipeline" to="/pipeline" />
            </div>
        </div>
    )
}

function Card({ title, value, to }: { title: string; value: string | number; to: string }) {
    const navigate = useNavigate()
    return (
        <div
            onClick={() => navigate(to)}
            className="bg-white shadow rounded p-4 text-center cursor-pointer hover:bg-gray-50 transition"
        >
            <h2 className="text-gray-500 text-sm font-medium mb-2">{title}</h2>
            <p className="text-2xl font-bold text-gray-800">{value}</p>
        </div>
    )
}