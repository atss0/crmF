import { useState } from 'react'
import type { Invoice } from '../types/invoice'
import InvoiceFormModal from '../components/InvoiceFormModal'
import { downloadInvoicePDF } from '../utils/pdfExport'

export default function InvoiceList() {
    const [invoices, setInvoices] = useState<Invoice[]>([])
    const [showModal, setShowModal] = useState(false)
    const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null)

    const handleFormSubmit = (data: Omit<Invoice, 'id'>) => {
        if (editingInvoice) {
            setInvoices((prev) =>
                prev.map((inv) => (inv.id === editingInvoice.id ? { ...inv, ...data } : inv))
            )
            setEditingInvoice(null)
        } else {
            const newInvoice: Invoice = {
                ...data,
                id: Date.now(),
            }
            setInvoices((prev) => [...prev, newInvoice])
        }
        setShowModal(false)
    }

    const deleteInvoice = (id: number) => {
        const confirmDelete = confirm('Are you sure you want to delete this invoice?')
        if (confirmDelete) {
            setInvoices((prev) => prev.filter((inv) => inv.id !== id))
        }
    }

    return (
        <div className="p-6">
            <div className="flex justify-between items-center mb-4">
                <h1 className="text-2xl font-bold">Invoices</h1>
                <button
                    className="bg-purple-600 text-white px-4 py-2 rounded"
                    onClick={() => setShowModal(true)}
                >
                    + New Invoice
                </button>
            </div>

            {showModal && (
                <InvoiceFormModal
                    onClose={() => {
                        setShowModal(false)
                        setEditingInvoice(null)
                    }}
                    onSubmit={handleFormSubmit}
                    initialData={editingInvoice || undefined}
                />
            )}

            <div className="overflow-x-auto">
                <table className="min-w-full bg-white shadow-md rounded">
                    <thead className="bg-gray-100">
                        <tr>
                            <th className="px-4 py-2 text-left">Customer</th>
                            <th className="px-4 py-2 text-left">Date</th>
                            <th className="px-4 py-2 text-left">Total</th>
                            <th className="px-4 py-2 text-left">Status</th>
                            <th className="px-4 py-2 text-left">Actions</th>
                            <th className="px-4 py-2 text-left">Download Invoice</th>
                        </tr>
                    </thead>
                    <tbody>
                        {invoices.length === 0 && (
                            <tr>
                                <td colSpan={5} className="text-center py-4 text-gray-500">
                                    No invoices found.
                                </td>
                            </tr>
                        )}
                        {invoices.map((inv) => (
                            <tr key={inv.id} id={`invoice-${inv.id}`} className="border-t hover:bg-gray-50">
                                <td className="px-4 py-2">{inv.customerName}</td>
                                <td className="px-4 py-2">{new Date(inv.date).toLocaleDateString()}</td>
                                <td className="px-4 py-2">
                                    $
                                    {inv.items
                                        .reduce((total, item) => total + item.price * item.quantity, 0)
                                        .toFixed(2)}
                                </td>
                                <td className="px-4 py-2 capitalize">{inv.status}</td>
                                <td className="px-4 py-2">
                                    <button
                                        className="text-blue-600 hover:underline mr-3"
                                        onClick={() => {
                                            setEditingInvoice(inv)
                                            setShowModal(true)
                                        }}
                                    >
                                        Edit
                                    </button>
                                    <button
                                        className="text-red-600 hover:underline"
                                        onClick={() => deleteInvoice(inv.id)}
                                    >
                                        Delete
                                    </button>
                                </td>
                                <td className="px-4 py-2">
                                    <button
                                        className="text-purple-600 hover:underline ml-3"
                                        onClick={() => downloadInvoicePDF(`pdf-content-${inv.id}`, `invoice-${inv.customerName}.pdf`)}
                                    >
                                        Download PDF
                                    </button>
                                </td>
                                <td style={{ position: 'absolute', left: '-9999px', top: '0' }}>
                                    <div id={`pdf-content-${inv.id}`} className="p-6 w-[600px] text-sm bg-white text-black">
                                        <h2 className="text-xl font-bold mb-4">INVOICE</h2>
                                        <p><strong>Customer:</strong> {inv.customerName}</p>
                                        <p><strong>Date:</strong> {new Date(inv.date).toLocaleDateString()}</p>
                                        <p><strong>Status:</strong> {inv.status}</p>

                                        <table className="mt-4 w-full border text-left text-sm">
                                            <thead className="bg-gray-100">
                                                <tr>
                                                    <th className="border px-2 py-1">Item</th>
                                                    <th className="border px-2 py-1">Quantity</th>
                                                    <th className="border px-2 py-1">Price</th>
                                                    <th className="border px-2 py-1">Total</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {inv.items.map((item, i) => (
                                                    <tr key={i}>
                                                        <td className="border px-2 py-1">{item.productName}</td>
                                                        <td className="border px-2 py-1">{item.quantity}</td>
                                                        <td className="border px-2 py-1">${item.price.toFixed(2)}</td>
                                                        <td className="border px-2 py-1">${(item.price * item.quantity).toFixed(2)}</td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>

                                        <div className="mt-4 text-right font-semibold">
                                            Total: $
                                            {inv.items.reduce((total, item) => total + item.price * item.quantity, 0).toFixed(2)}
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    )
}