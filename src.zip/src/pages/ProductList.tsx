import { useState } from 'react'
import type { Product } from '../types/product'
import ProductFormModal from '../components/ProductFormModal'

export default function ProductList() {
    const [products, setProducts] = useState<Product[]>([])
    const [showModal, setShowModal] = useState(false)
    const [editingProduct, setEditingProduct] = useState<Product | null>(null)

    const handleFormSubmit = (data: Omit<Product, 'id'>) => {
        if (editingProduct) {
            setProducts((prev) =>
                prev.map((p) => (p.id === editingProduct.id ? { ...p, ...data } : p))
            )
            setEditingProduct(null)
        } else {
            const newProduct: Product = { ...data, id: Date.now() }
            setProducts((prev) => [...prev, newProduct])
        }
        setShowModal(false)
    }

    const deleteProduct = (id: number) => {
        const confirmDelete = confirm('Are you sure you want to delete this product?')
        if (confirmDelete) {
            setProducts((prev) => prev.filter((p) => p.id !== id))
        }
    }

    return (
        <div className="p-6">
            <div className="flex justify-between items-center mb-4">
                <h1 className="text-2xl font-bold">Products</h1>
                <button
                    className="bg-blue-600 text-white px-4 py-2 rounded"
                    onClick={() => setShowModal(true)}
                >
                    + Add Product
                </button>
            </div>

            {showModal && (
                <ProductFormModal
                    onClose={() => {
                        setShowModal(false)
                        setEditingProduct(null)
                    }}
                    onSubmit={handleFormSubmit}
                    initialData={editingProduct ?? undefined}
                />
            )}

            <div className="overflow-x-auto">
                <table className="min-w-full bg-white shadow-md rounded">
                    <thead className="bg-gray-100">
                        <tr>
                            <th className="px-4 py-2 text-left">Name</th>
                            <th className="px-4 py-2 text-left">Description</th>
                            <th className="px-4 py-2 text-left">Price</th>
                            <th className="px-4 py-2 text-left">Stock</th>
                            <th className="px-4 py-2 text-left">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {products.length === 0 && (
                            <tr>
                                <td colSpan={5} className="text-center py-4 text-gray-500">
                                    No products found.
                                </td>
                            </tr>
                        )}
                        {products.map((product) => (
                            <tr key={product.id} className="border-t hover:bg-gray-50">
                                <td className="px-4 py-2">{product.name}</td>
                                <td className="px-4 py-2">{product.description}</td>
                                <td className="px-4 py-2">${product.price.toFixed(2)}</td>
                                <td className="px-4 py-2">{product.stock}</td>
                                <td className="px-4 py-2">
                                    <button
                                        className="text-blue-600 hover:underline mr-3"
                                        onClick={() => {
                                            setEditingProduct(product)
                                            setShowModal(true)
                                        }}
                                    >
                                        Edit
                                    </button>
                                    <button
                                        className="text-red-600 hover:underline"
                                        onClick={() => deleteProduct(product.id)}
                                    >
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    )
}