import { useState } from 'react'
import type { Task } from '../types/task'
import TaskFormModal from '../components/TaskFormModal'

export default function TaskList() {
    const [tasks, setTasks] = useState<Task[]>([])
    const [showModal, setShowModal] = useState(false)
    const [editingTask, setEditingTask] = useState<Task | null>(null)

    const handleFormSubmit = (data: Omit<Task, 'id'>) => {
        if (editingTask) {
            setTasks((prev) =>
                prev.map((task) =>
                    task.id === editingTask.id ? { ...task, ...data } : task
                )
            )
            setEditingTask(null)
        } else {
            const withId: Task = { ...data, id: Date.now() }
            setTasks((prev) => [...prev, withId])
        }

        setShowModal(false)
    }

    const deleteTask = (id: number) => {
        const confirmed = confirm('Are you sure you want to delete this task?')
        if (confirmed) {
            setTasks((prev) => prev.filter((task) => task.id !== id))
        }
    }

    return (
        <div className="p-6">
            <div className="flex justify-between items-center mb-4">
                <h1 className="text-2xl font-bold">Task List</h1>
                <button
                    className="bg-green-600 text-white px-4 py-2 rounded"
                    onClick={() => setShowModal(true)}
                >
                    + Add Task
                </button>
            </div>

            {showModal && (
                <TaskFormModal
                    onClose={() => {
                        setShowModal(false)
                        setEditingTask(null)
                    }}
                    onSubmit={handleFormSubmit}
                    initialData={editingTask}
                />
            )}

            <div className="space-y-3">
                {tasks.length === 0 && <p className="text-gray-500">No tasks yet.</p>}

                {tasks.map((task) => (
                    <div key={task.id} className="p-4 bg-white shadow rounded flex justify-between items-center">
                        <div>
                            <h3 className="font-semibold">{task.title}</h3>
                            <p className="text-sm text-gray-600">{task.description}</p>
                            <p className="text-xs text-gray-400">Due: {new Date(task.dueDate).toLocaleDateString()}</p>
                        </div>
                        <span
                            onClick={() =>
                                setTasks((prev) =>
                                    prev.map((t) =>
                                        t.id === task.id ? { ...t, status: t.status === 'done' ? 'pending' : 'done' } : t
                                    )
                                )
                            }
                            className={`text-xs px-2 py-1 rounded cursor-pointer transition ${task.status === 'done'
                                    ? 'bg-green-100 text-green-600'
                                    : 'bg-yellow-100 text-yellow-600'
                                }`}
                        >
                            {task.status}
                        </span>
                        <div className="flex gap-2 ml-auto">
                            <button
                                onClick={() => {
                                    setEditingTask(task)
                                    setShowModal(true)
                                }}
                                className="text-blue-600 hover:underline text-sm"
                            >
                                Edit
                            </button>

                            <button
                                onClick={() => deleteTask(task.id)}
                                className="text-red-600 hover:underline text-sm"
                            >
                                Delete
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    )
}